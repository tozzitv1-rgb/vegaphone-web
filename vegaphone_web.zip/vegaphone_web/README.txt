╔══════════════════════════════════════════════════════════════╗
║         VEGA PHONE — App Web                                 ║
║         Come pubblicare online (GRATIS) su Render.com        ║
╚══════════════════════════════════════════════════════════════╝

════════════════════════════════════
 PASSO 1 — Carica su GitHub
════════════════════════════════════
1. Vai su github.com e crea un account (gratis)
2. Crea un nuovo repository (es. "vegaphone-web")
3. Carica tutti i file di questa cartella nel repository

════════════════════════════════════
 PASSO 2 — Deploy su Render.com
════════════════════════════════════
1. Vai su render.com e crea un account (gratis)
2. Clicca "New +" → "Web Service"
3. Collega il tuo account GitHub
4. Seleziona il repository "vegaphone-web"
5. Compila i campi:
   - Name: vegaphone
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: gunicorn app:app
6. Clicca "Create Web Service"

Dopo qualche minuto l'app sarà online su:
  https://vegaphone.onrender.com  (o simile)

════════════════════════════════════
 PASSO 3 — Avvio locale (test)
════════════════════════════════════
Per testare sul tuo PC prima del deploy:

  pip install flask
  python app.py

Poi apri il browser su: http://localhost:5000

════════════════════════════════════
 NOTA SUL DATABASE
════════════════════════════════════
Il database SQLite viene creato automaticamente al primo avvio.
Se vuoi importare i dati dal programma desktop precedente,
copia il file vegaphone_db.sqlite nella stessa cartella di app.py.

Su Render.com (piano gratuito) i dati si resettano se il servizio
va in sleep. Per dati persistenti usa Render Disk o converti a PostgreSQL.

════════════════════════════════════
 LINK STATO RIPARAZIONE
════════════════════════════════════
Per ogni riparazione esiste una pagina pubblica accessibile dal cliente:
  https://tuo-dominio/riparazioni/{ID}/stato

Il cliente può vedere lo stato della riparazione in tempo reale
senza bisogno di login.
