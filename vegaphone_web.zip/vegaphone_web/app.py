"""
╔══════════════════════════════════════════════════════════════╗
║         VEGA PHONE — App Web Flask                           ║
║         Versione 2.0  |  Database SQLite integrato           ║
╚══════════════════════════════════════════════════════════════╝
Deploy su Render.com:
  1. Carica questa cartella su GitHub
  2. Vai su render.com → New Web Service
  3. Collega il repo, start command: gunicorn app:app
"""

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash
import sqlite3, os
from datetime import datetime, date
from functools import wraps

app = Flask(__name__)
app.secret_key = "vegaphone_secret_2024"

DB_PATH = os.environ.get("DB_PATH", "vegaphone_db.sqlite")

# ══════════════════════════════════════════════════════════════
#  DATABASE
# ══════════════════════════════════════════════════════════════
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS clienti (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        cognome TEXT NOT NULL,
        telefono TEXT,
        email TEXT,
        indirizzo TEXT,
        note TEXT,
        data_reg TEXT DEFAULT (date('now'))
    );
    CREATE TABLE IF NOT EXISTS prodotti (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codice TEXT UNIQUE,
        nome TEXT NOT NULL,
        categoria TEXT,
        marca TEXT,
        prezzo_acquisto REAL DEFAULT 0,
        prezzo_vendita REAL DEFAULT 0,
        quantita INTEGER DEFAULT 0,
        scorta_minima INTEGER DEFAULT 1,
        note TEXT
    );
    CREATE TABLE IF NOT EXISTS vendite (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero TEXT UNIQUE,
        id_cliente INTEGER,
        data TEXT DEFAULT (date('now')),
        totale REAL DEFAULT 0,
        sconto REAL DEFAULT 0,
        pagamento TEXT DEFAULT 'Contanti',
        note TEXT,
        FOREIGN KEY(id_cliente) REFERENCES clienti(id)
    );
    CREATE TABLE IF NOT EXISTS vendite_righe (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_vendita INTEGER,
        id_prodotto INTEGER,
        descrizione TEXT,
        quantita INTEGER DEFAULT 1,
        prezzo_unitario REAL DEFAULT 0,
        totale_riga REAL DEFAULT 0,
        FOREIGN KEY(id_vendita) REFERENCES vendite(id)
    );
    CREATE TABLE IF NOT EXISTS riparazioni (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero TEXT UNIQUE,
        id_cliente INTEGER,
        dispositivo TEXT,
        problema TEXT,
        stato TEXT DEFAULT 'In attesa',
        tecnico TEXT,
        costo REAL DEFAULT 0,
        acconto REAL DEFAULT 0,
        data_entrata TEXT DEFAULT (date('now')),
        data_uscita TEXT,
        note TEXT,
        FOREIGN KEY(id_cliente) REFERENCES clienti(id)
    );
    CREATE TABLE IF NOT EXISTS cassa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT DEFAULT (date('now')),
        tipo TEXT,
        categoria TEXT,
        descrizione TEXT,
        importo REAL DEFAULT 0,
        pagamento TEXT DEFAULT 'Contanti',
        riferimento TEXT
    );
    """)
    conn.commit()
    conn.close()

init_db()

# ══════════════════════════════════════════════════════════════
#  HELPER
# ══════════════════════════════════════════════════════════════
def q(sql, params=(), one=False):
    conn = get_db()
    cur = conn.execute(sql, params)
    conn.commit()
    result = cur.fetchone() if one else cur.fetchall()
    conn.close()
    return result

def qw(sql, params=()):
    conn = get_db()
    cur = conn.execute(sql, params)
    conn.commit()
    lid = cur.lastrowid
    conn.close()
    return lid

# ══════════════════════════════════════════════════════════════
#  DASHBOARD
# ══════════════════════════════════════════════════════════════
@app.route("/")
def dashboard():
    oggi = date.today().isoformat()
    kpis = {
        "clienti":     q("SELECT COUNT(*) FROM clienti", one=True)[0],
        "prodotti":    q("SELECT COUNT(*) FROM prodotti", one=True)[0],
        "vendite_oggi": q(f"SELECT COUNT(*) FROM vendite WHERE data='{oggi}'", one=True)[0],
        "incasso_oggi": q(f"SELECT COALESCE(SUM(importo),0) FROM cassa WHERE tipo='Entrata' AND data='{oggi}'", one=True)[0],
        "riparazioni_aperte": q("SELECT COUNT(*) FROM riparazioni WHERE stato NOT IN ('Consegnato')", one=True)[0],
        "sotto_scorta": q("SELECT COUNT(*) FROM prodotti WHERE quantita <= scorta_minima", one=True)[0],
    }
    ultime_vendite = q(
        "SELECT v.numero, COALESCE(c.nome||' '||c.cognome,'Generico'), v.data, v.totale, v.pagamento "
        "FROM vendite v LEFT JOIN clienti c ON v.id_cliente=c.id ORDER BY v.id DESC LIMIT 8")
    ultime_rip = q(
        "SELECT r.numero, COALESCE(c.nome||' '||c.cognome,'N/D'), r.dispositivo, r.stato, r.data_entrata "
        "FROM riparazioni r LEFT JOIN clienti c ON r.id_cliente=c.id ORDER BY r.id DESC LIMIT 8")
    return render_template("dashboard.html", kpis=kpis,
                           ultime_vendite=ultime_vendite, ultime_rip=ultime_rip)

# ══════════════════════════════════════════════════════════════
#  CLIENTI
# ══════════════════════════════════════════════════════════════
@app.route("/clienti")
def clienti():
    cerca = request.args.get("cerca", "")
    like = f"%{cerca}%"
    rows = q("SELECT id,nome,cognome,telefono,email,indirizzo,data_reg FROM clienti "
             "WHERE nome LIKE ? OR cognome LIKE ? OR telefono LIKE ? OR email LIKE ? ORDER BY cognome,nome",
             (like,like,like,like))
    return render_template("clienti.html", rows=rows, cerca=cerca)

@app.route("/clienti/nuovo", methods=["GET","POST"])
def cliente_nuovo():
    if request.method == "POST":
        d = request.form
        if not d.get("nome"):
            flash("Nome obbligatorio", "error"); return redirect(url_for("cliente_nuovo"))
        qw("INSERT INTO clienti(nome,cognome,telefono,email,indirizzo,note) VALUES(?,?,?,?,?,?)",
           (d["nome"],d.get("cognome",""),d.get("telefono",""),d.get("email",""),d.get("indirizzo",""),d.get("note","")))
        flash("Cliente aggiunto!", "success"); return redirect(url_for("clienti"))
    return render_template("cliente_form.html", cliente=None, titolo="Nuovo Cliente")

@app.route("/clienti/<int:cid>/modifica", methods=["GET","POST"])
def cliente_modifica(cid):
    cliente = q("SELECT * FROM clienti WHERE id=?", (cid,), one=True)
    if request.method == "POST":
        d = request.form
        qw("UPDATE clienti SET nome=?,cognome=?,telefono=?,email=?,indirizzo=?,note=? WHERE id=?",
           (d["nome"],d.get("cognome",""),d.get("telefono",""),d.get("email",""),d.get("indirizzo",""),d.get("note",""),cid))
        flash("Cliente aggiornato!", "success"); return redirect(url_for("clienti"))
    return render_template("cliente_form.html", cliente=cliente, titolo="Modifica Cliente")

@app.route("/clienti/<int:cid>/elimina", methods=["POST"])
def cliente_elimina(cid):
    qw("DELETE FROM clienti WHERE id=?", (cid,))
    flash("Cliente eliminato.", "success"); return redirect(url_for("clienti"))

# ══════════════════════════════════════════════════════════════
#  MAGAZZINO / PRODOTTI
# ══════════════════════════════════════════════════════════════
@app.route("/prodotti")
def prodotti():
    cerca = request.args.get("cerca", "")
    like = f"%{cerca}%"
    rows = q("SELECT id,codice,nome,categoria,marca,prezzo_acquisto,prezzo_vendita,quantita,scorta_minima "
             "FROM prodotti WHERE nome LIKE ? OR codice LIKE ? OR marca LIKE ? OR categoria LIKE ? ORDER BY nome",
             (like,like,like,like))
    return render_template("prodotti.html", rows=rows, cerca=cerca)

@app.route("/prodotti/nuovo", methods=["GET","POST"])
def prodotto_nuovo():
    if request.method == "POST":
        d = request.form
        if not d.get("nome"):
            flash("Nome obbligatorio", "error"); return redirect(url_for("prodotto_nuovo"))
        row = q("SELECT codice FROM prodotti WHERE codice LIKE 'VP%' ORDER BY CAST(SUBSTR(codice,3) AS INTEGER) DESC LIMIT 1", one=True)
        n = 1
        if row and row[0]:
            try: n = int(row[0][2:]) + 1
            except: n = 1
        auto_cod = f"VP{n:05d}"
        codice = d.get("codice","").strip() or auto_cod
        try:
            qw("INSERT INTO prodotti(codice,nome,categoria,marca,prezzo_acquisto,prezzo_vendita,quantita,scorta_minima,note) VALUES(?,?,?,?,?,?,?,?,?)",
               (codice,d["nome"],d.get("categoria",""),d.get("marca",""),
                float(d.get("prezzo_acquisto") or 0), float(d.get("prezzo_vendita") or 0),
                int(d.get("quantita") or 0), int(d.get("scorta_minima") or 1), d.get("note","")))
            flash("Prodotto aggiunto!", "success"); return redirect(url_for("prodotti"))
        except Exception as e:
            flash(str(e), "error"); return redirect(url_for("prodotto_nuovo"))
    return render_template("prodotto_form.html", prodotto=None, titolo="Nuovo Prodotto")

@app.route("/prodotti/<int:pid>/modifica", methods=["GET","POST"])
def prodotto_modifica(pid):
    prodotto = q("SELECT * FROM prodotti WHERE id=?", (pid,), one=True)
    if request.method == "POST":
        d = request.form
        try:
            qw("UPDATE prodotti SET codice=?,nome=?,categoria=?,marca=?,prezzo_acquisto=?,prezzo_vendita=?,quantita=?,scorta_minima=?,note=? WHERE id=?",
               (d.get("codice",""),d["nome"],d.get("categoria",""),d.get("marca",""),
                float(d.get("prezzo_acquisto") or 0), float(d.get("prezzo_vendita") or 0),
                int(d.get("quantita") or 0), int(d.get("scorta_minima") or 1), d.get("note",""),pid))
            flash("Prodotto aggiornato!", "success"); return redirect(url_for("prodotti"))
        except Exception as e:
            flash(str(e), "error")
    return render_template("prodotto_form.html", prodotto=prodotto, titolo="Modifica Prodotto")

@app.route("/prodotti/<int:pid>/elimina", methods=["POST"])
def prodotto_elimina(pid):
    qw("DELETE FROM prodotti WHERE id=?", (pid,))
    flash("Prodotto eliminato.", "success"); return redirect(url_for("prodotti"))

# ══════════════════════════════════════════════════════════════
#  VENDITE
# ══════════════════════════════════════════════════════════════
@app.route("/vendite")
def vendite():
    cerca = request.args.get("cerca", "")
    like = f"%{cerca}%"
    rows = q("SELECT v.id,v.numero,COALESCE(c.nome||' '||c.cognome,'Generico'),v.data,v.totale,v.sconto,v.pagamento "
             "FROM vendite v LEFT JOIN clienti c ON v.id_cliente=c.id "
             "WHERE v.numero LIKE ? OR c.nome LIKE ? OR c.cognome LIKE ? ORDER BY v.id DESC",
             (like,like,like))
    return render_template("vendite.html", rows=rows, cerca=cerca)

@app.route("/vendite/nuova", methods=["GET","POST"])
def vendita_nuova():
    clienti_list = q("SELECT id, nome||' '||cognome FROM clienti ORDER BY cognome")
    prodotti_list = q("SELECT id, nome, codice, prezzo_vendita, quantita FROM prodotti ORDER BY nome")
    if request.method == "POST":
        d = request.form
        righe = []
        i = 0
        while f"prod_{i}" in d:
            pid = d.get(f"prod_{i}","")
            desc = d.get(f"desc_{i}","")
            qty = int(d.get(f"qty_{i}") or 1)
            prezzo = float(d.get(f"prezzo_{i}") or 0)
            if desc:
                righe.append({"id_prod": pid, "desc": desc, "qty": qty, "prezzo": prezzo, "tot": qty*prezzo})
            i += 1
        if not righe:
            flash("Aggiungi almeno un prodotto", "error")
            return render_template("vendita_nuova.html", clienti=clienti_list, prodotti=prodotti_list)
        sconto = float(d.get("sconto") or 0)
        totale = sum(r["tot"] for r in righe) - sconto
        pagamento = d.get("pagamento","Contanti")
        id_cliente = d.get("id_cliente") or None
        num = f"VEN{datetime.now().strftime('%Y%m%d%H%M%S')}"
        id_v = qw("INSERT INTO vendite(numero,id_cliente,totale,sconto,pagamento) VALUES(?,?,?,?,?)",
                  (num, id_cliente, totale, sconto, pagamento))
        for r in righe:
            qw("INSERT INTO vendite_righe(id_vendita,id_prodotto,descrizione,quantita,prezzo_unitario,totale_riga) VALUES(?,?,?,?,?,?)",
               (id_v, r["id_prod"] or None, r["desc"], r["qty"], r["prezzo"], r["tot"]))
            if r["id_prod"]:
                qw("UPDATE prodotti SET quantita=quantita-? WHERE id=?", (r["qty"], r["id_prod"]))
        qw("INSERT INTO cassa(tipo,categoria,descrizione,importo,pagamento,riferimento) VALUES(?,?,?,?,?,?)",
           ("Entrata","Vendita",f"Vendita {num}",totale,pagamento,num))
        flash(f"Vendita {num} registrata! Totale: € {totale:.2f}", "success")
        return redirect(url_for("vendite"))
    return render_template("vendita_nuova.html", clienti=clienti_list, prodotti=prodotti_list)

@app.route("/vendite/<int:vid>/elimina", methods=["POST"])
def vendita_elimina(vid):
    qw("DELETE FROM vendite_righe WHERE id_vendita=?", (vid,))
    qw("DELETE FROM vendite WHERE id=?", (vid,))
    flash("Vendita eliminata.", "success"); return redirect(url_for("vendite"))

@app.route("/vendite/<int:vid>/dettaglio")
def vendita_dettaglio(vid):
    v = q("SELECT v.*, COALESCE(c.nome||' '||c.cognome,'Cliente generico') as cn "
          "FROM vendite v LEFT JOIN clienti c ON v.id_cliente=c.id WHERE v.id=?", (vid,), one=True)
    righe = q("SELECT descrizione,quantita,prezzo_unitario,totale_riga FROM vendite_righe WHERE id_vendita=?", (vid,))
    return render_template("vendita_dettaglio.html", v=v, righe=righe)

# ══════════════════════════════════════════════════════════════
#  RIPARAZIONI
# ══════════════════════════════════════════════════════════════
@app.route("/riparazioni")
def riparazioni():
    cerca = request.args.get("cerca", "")
    stato_f = request.args.get("stato", "")
    like = f"%{cerca}%"
    sql = ("SELECT r.id,r.numero,COALESCE(c.nome||' '||c.cognome,'N/D'),r.dispositivo,"
           "r.problema,r.stato,r.costo,r.data_entrata,r.data_uscita "
           "FROM riparazioni r LEFT JOIN clienti c ON r.id_cliente=c.id "
           "WHERE (r.dispositivo LIKE ? OR r.problema LIKE ? OR r.stato LIKE ? OR c.nome LIKE ? OR c.cognome LIKE ?)")
    params = [like,like,like,like,like]
    if stato_f:
        sql += " AND r.stato=?"
        params.append(stato_f)
    sql += " ORDER BY r.id DESC"
    rows = q(sql, params)
    return render_template("riparazioni.html", rows=rows, cerca=cerca, stato_f=stato_f)

@app.route("/riparazioni/nuova", methods=["GET","POST"])
def riparazione_nuova():
    clienti_list = q("SELECT id, nome||' '||cognome FROM clienti ORDER BY cognome")
    if request.method == "POST":
        d = request.form
        num = f"RIP{datetime.now().strftime('%Y%m%d%H%M%S')}"
        id_cli = d.get("id_cliente") or None
        qw("INSERT INTO riparazioni(numero,id_cliente,dispositivo,problema,stato,tecnico,costo,acconto,data_uscita,note) VALUES(?,?,?,?,?,?,?,?,?,?)",
           (num, id_cli, d.get("dispositivo",""), d.get("problema",""),
            d.get("stato","In attesa"), d.get("tecnico",""),
            float(d.get("costo") or 0), float(d.get("acconto") or 0),
            d.get("data_uscita",""), d.get("note","")))
        flash(f"Riparazione {num} creata!", "success")
        return redirect(url_for("riparazioni"))
    return render_template("riparazione_form.html", rip=None, clienti=clienti_list, titolo="Nuova Riparazione")

@app.route("/riparazioni/<int:rid>/modifica", methods=["GET","POST"])
def riparazione_modifica(rid):
    rip = q("SELECT * FROM riparazioni WHERE id=?", (rid,), one=True)
    clienti_list = q("SELECT id, nome||' '||cognome FROM clienti ORDER BY cognome")
    if request.method == "POST":
        d = request.form
        id_cli = d.get("id_cliente") or None
        qw("UPDATE riparazioni SET id_cliente=?,dispositivo=?,problema=?,stato=?,tecnico=?,costo=?,acconto=?,data_uscita=?,note=? WHERE id=?",
           (id_cli, d.get("dispositivo",""), d.get("problema",""),
            d.get("stato","In attesa"), d.get("tecnico",""),
            float(d.get("costo") or 0), float(d.get("acconto") or 0),
            d.get("data_uscita",""), d.get("note",""), rid))
        flash("Riparazione aggiornata!", "success")
        return redirect(url_for("riparazioni"))
    return render_template("riparazione_form.html", rip=rip, clienti=clienti_list, titolo="Modifica Riparazione")

@app.route("/riparazioni/<int:rid>/elimina", methods=["POST"])
def riparazione_elimina(rid):
    qw("DELETE FROM riparazioni WHERE id=?", (rid,))
    flash("Riparazione eliminata.", "success"); return redirect(url_for("riparazioni"))

@app.route("/riparazioni/<int:rid>/stato")
def riparazione_stato(rid):
    """Pagina pubblica stato riparazione (per il cliente)"""
    r = q("SELECT rip.*, COALESCE(c.nome||' '||c.cognome,'N/D') as cn "
          "FROM riparazioni rip LEFT JOIN clienti c ON rip.id_cliente=c.id WHERE rip.id=?", (rid,), one=True)
    if not r:
        return "Riparazione non trovata", 404
    return render_template("stato_riparazione.html", r=r)

# ══════════════════════════════════════════════════════════════
#  CASSA
# ══════════════════════════════════════════════════════════════
@app.route("/cassa")
def cassa():
    cerca = request.args.get("cerca", "")
    like = f"%{cerca}%"
    rows = q("SELECT id,data,tipo,categoria,descrizione,importo,pagamento,riferimento "
             "FROM cassa WHERE descrizione LIKE ? OR categoria LIKE ? OR tipo LIKE ? ORDER BY id DESC",
             (like,like,like))
    tot_e = q("SELECT COALESCE(SUM(importo),0) FROM cassa WHERE tipo='Entrata'", one=True)[0]
    tot_u = q("SELECT COALESCE(SUM(importo),0) FROM cassa WHERE tipo='Uscita'", one=True)[0]
    saldo = tot_e - tot_u
    return render_template("cassa.html", rows=rows, cerca=cerca, tot_e=tot_e, tot_u=tot_u, saldo=saldo)

@app.route("/cassa/nuovo", methods=["GET","POST"])
def cassa_nuovo():
    if request.method == "POST":
        d = request.form
        if not d.get("descrizione"):
            flash("Descrizione obbligatoria", "error"); return redirect(url_for("cassa_nuovo"))
        qw("INSERT INTO cassa(tipo,categoria,descrizione,importo,pagamento,riferimento) VALUES(?,?,?,?,?,?)",
           (d.get("tipo","Entrata"),d.get("categoria",""),d.get("descrizione",""),
            float(d.get("importo") or 0),d.get("pagamento","Contanti"),d.get("riferimento","")))
        flash("Movimento aggiunto!", "success"); return redirect(url_for("cassa"))
    return render_template("cassa_form.html", mov=None, titolo="Nuovo Movimento")

@app.route("/cassa/<int:mid>/modifica", methods=["GET","POST"])
def cassa_modifica(mid):
    mov = q("SELECT * FROM cassa WHERE id=?", (mid,), one=True)
    if request.method == "POST":
        d = request.form
        qw("UPDATE cassa SET tipo=?,categoria=?,descrizione=?,importo=?,pagamento=?,riferimento=? WHERE id=?",
           (d.get("tipo",""),d.get("categoria",""),d.get("descrizione",""),
            float(d.get("importo") or 0),d.get("pagamento",""),d.get("riferimento",""),mid))
        flash("Movimento aggiornato!", "success"); return redirect(url_for("cassa"))
    return render_template("cassa_form.html", mov=mov, titolo="Modifica Movimento")

@app.route("/cassa/<int:mid>/elimina", methods=["POST"])
def cassa_elimina(mid):
    qw("DELETE FROM cassa WHERE id=?", (mid,))
    flash("Movimento eliminato.", "success"); return redirect(url_for("cassa"))

# ══════════════════════════════════════════════════════════════
#  MARGINI
# ══════════════════════════════════════════════════════════════
@app.route("/margini")
def margini():
    dal = request.args.get("dal", datetime.now().strftime("%Y-%m-01"))
    al  = request.args.get("al",  datetime.now().strftime("%Y-%m-%d"))

    vendite_righe = q(
        "SELECT vr.id_prodotto, vr.descrizione, vr.quantita, vr.prezzo_unitario, vr.totale_riga,"
        " COALESCE(p.prezzo_acquisto, 0) as costo_unit"
        " FROM vendite_righe vr JOIN vendite v ON vr.id_vendita=v.id"
        " LEFT JOIN prodotti p ON vr.id_prodotto=p.id WHERE v.data BETWEEN ? AND ?", (dal,al))
    riparazioni_list = q(
        "SELECT id,numero,costo,acconto FROM riparazioni"
        " WHERE stato IN ('Pronto','Consegnato') AND data_entrata BETWEEN ? AND ?", (dal,al))
    entrate_cassa = q("SELECT COALESCE(SUM(importo),0) FROM cassa WHERE tipo='Entrata' AND data BETWEEN ? AND ?", (dal,al), one=True)[0]
    uscite_cassa  = q("SELECT COALESCE(SUM(importo),0) FROM cassa WHERE tipo='Uscita' AND data BETWEEN ? AND ?", (dal,al), one=True)[0]

    ricavo_vendite  = sum(r[4] for r in vendite_righe)
    costo_vendite   = sum(r[2] * r[5] for r in vendite_righe)
    margine_vendite = ricavo_vendite - costo_vendite
    pct_vendite     = (margine_vendite / ricavo_vendite * 100) if ricavo_vendite else 0

    ricavo_rip  = sum(r[2] or 0 for r in riparazioni_list)
    ricavo_tot  = ricavo_vendite + ricavo_rip
    costo_tot   = costo_vendite + uscite_cassa
    margine_tot = ricavo_tot - costo_tot
    pct_tot     = (margine_tot / ricavo_tot * 100) if ricavo_tot else 0

    # Top prodotti
    from collections import defaultdict
    agg = defaultdict(lambda: {"qty":0,"ricavo":0,"costo":0})
    for r in vendite_righe:
        desc = r[1] or "N/D"
        agg[desc]["qty"] += r[2]
        agg[desc]["ricavo"] += r[4]
        agg[desc]["costo"] += r[2]*r[5]
    top_prod = sorted(agg.items(), key=lambda x: x[1]["ricavo"]-x[1]["costo"], reverse=True)[:10]

    return render_template("margini.html",
        dal=dal, al=al,
        ricavo_vendite=ricavo_vendite, costo_vendite=costo_vendite,
        margine_vendite=margine_vendite, pct_vendite=pct_vendite,
        ricavo_rip=ricavo_rip, ricavo_tot=ricavo_tot,
        costo_tot=costo_tot, margine_tot=margine_tot, pct_tot=pct_tot,
        entrate_cassa=entrate_cassa, uscite_cassa=uscite_cassa,
        top_prod=top_prod, riparazioni=riparazioni_list)

# ══════════════════════════════════════════════════════════════
#  API JSON (per autocomplete vendite)
# ══════════════════════════════════════════════════════════════
@app.route("/api/prodotti")
def api_prodotti():
    rows = q("SELECT id,nome,codice,prezzo_vendita,quantita FROM prodotti ORDER BY nome")
    return jsonify([dict(r) for r in rows])

@app.route("/api/clienti")
def api_clienti():
    rows = q("SELECT id, nome||' '||cognome as label FROM clienti ORDER BY cognome")
    return jsonify([dict(r) for r in rows])

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
